set.seed(123)   # for reproducibility
n <- 25
mu <- 45
sigma <- 2

# generate normally distributed baking times
sample <- rnorm(n, mean = mu, sd = sigma)
sample

t.test(sample, mu = 46, alternative = "less", conf.level = 0.95)

